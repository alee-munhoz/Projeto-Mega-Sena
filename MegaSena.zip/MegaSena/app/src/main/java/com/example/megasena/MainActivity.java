package com.example.megasena;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView n1,n2,n3,n4,n5,n6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        n3 = findViewById(R.id.n3);
        n4 = findViewById(R.id.n4);
        n5 = findViewById(R.id.n5);
        n6 = findViewById(R.id.n6);
    }

    public void gerarNumeros(View view){

        Random random = new Random();
        int[] numeros = new int[6];

        for(int i=0;i<6;i++){
            numeros[i] = random.nextInt(60)+1;
        }

        java.util.Arrays.sort(numeros);

        n1.setText(String.valueOf(numeros[0]));
        n2.setText(String.valueOf(numeros[1]));
        n3.setText(String.valueOf(numeros[2]));
        n4.setText(String.valueOf(numeros[3]));
        n5.setText(String.valueOf(numeros[4]));
        n6.setText(String.valueOf(numeros[5]));
    }

    public void limparNumeros(View view){

        n1.setText("0");
        n2.setText("0");
        n3.setText("0");
        n4.setText("0");
        n5.setText("0");
        n6.setText("0");

    }
}